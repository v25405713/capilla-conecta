# Capilla Conecta - Proyecto Android Nativo

Este proyecto contiene el código fuente completo listo para abrir en Android Studio.
